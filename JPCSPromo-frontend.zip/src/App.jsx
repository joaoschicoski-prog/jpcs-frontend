import { useState } from "react";
import { AuthProvider } from "./context/AuthContext";
import { ListProvider } from "./context/ListContext";
import Header from "./components/Header";
import BottomNav from "./components/BottomNav";
import Home from "./pages/Home";
import Ranking from "./pages/Ranking";
import Login from "./pages/Login";
import ShoppingList from "./pages/ShoppingList";
import Profile from "./pages/Profile";
import Admin from "./pages/Admin";

function AppInner() {
  const [page, setPage] = useState("home");

  const pages = {
    home: <Home />,
    ranking: <Ranking />,
    login: <Login setPage={setPage} />,
    list: <ShoppingList setPage={setPage} />,
    profile: <Profile setPage={setPage} />,
    admin: <Admin setPage={setPage} />,
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      <Header page={page} setPage={setPage} />
      <main style={{ flex: 1, overflowY: "auto" }}>
        {pages[page] || <Home />}
      </main>
      <BottomNav page={page} setPage={setPage} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ListProvider>
        <AppInner />
      </ListProvider>
    </AuthProvider>
  );
}
