import { useAuth } from "../context/AuthContext";
import { useList } from "../context/ListContext";

export default function ProductCard({ product, cheapestPrice, supermarket, onClick }) {
  const { isLogged } = useAuth();
  const { isFavorite, toggleFavorite, isInList, addToList, removeFromList } = useList();

  const fav = isFavorite(product.id);
  const inList = isInList(product.id);

  const handleFav = (e) => {
    e.stopPropagation();
    if (!isLogged) return;
    toggleFavorite(product);
  };

  const handleList = (e) => {
    e.stopPropagation();
    if (!isLogged) return;
    if (inList) removeFromList(product.id);
    else addToList(product);
  };

  return (
    <div
      onClick={onClick}
      style={{
        background: "var(--white)",
        border: "1px solid var(--gray-200)",
        borderRadius: "var(--radius-lg)",
        padding: "14px 16px",
        display: "flex", alignItems: "center", gap: 14,
        cursor: "pointer",
        transition: "border-color 0.15s, box-shadow 0.15s",
        animation: "fadeUp 0.3s ease both",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "var(--green-400)";
        e.currentTarget.style.boxShadow = "var(--shadow-sm)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "var(--gray-200)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      {product.image_url ? (
        <img
          src={product.image_url}
          alt={product.name}
          style={{
            width: 52, height: 52, borderRadius: "var(--radius-md)",
            objectFit: "cover", flexShrink: 0,
            background: "var(--gray-100)",
          }}
        />
      ) : (
        <div style={{
          width: 52, height: 52, borderRadius: "var(--radius-md)",
          background: "var(--green-50)",
          display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0, fontSize: 22,
        }}>
          🛒
        </div>
      )}

      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{
          fontFamily: "var(--font-display)", fontWeight: 700,
          fontSize: 15, color: "var(--gray-900)",
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        }}>
          {product.name}
        </p>
        <p style={{ fontSize: 12, color: "var(--gray-500)", marginTop: 2 }}>
          {product.category || "Sem categoria"} · {product.brand || "Sem marca"}
        </p>
        {cheapestPrice && (
          <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{
              fontSize: 16, fontWeight: 800, fontFamily: "var(--font-display)",
              color: "var(--green-600)",
            }}>
              R$ {Number(cheapestPrice).toFixed(2)}
            </span>
            {supermarket && (
              <span style={{
                fontSize: 11, color: "var(--gray-500)",
                background: "var(--gray-100)", borderRadius: "var(--radius-full)",
                padding: "2px 8px",
              }}>
                {supermarket}
              </span>
            )}
          </div>
        )}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
        {isLogged && (
          <>
            <button
              onClick={handleFav}
              style={{
                width: 32, height: 32, borderRadius: "var(--radius-full)",
                display: "flex", alignItems: "center", justifyContent: "center",
                background: fav ? "var(--red-50)" : "var(--gray-100)",
                transition: "background 0.15s",
              }}
              title={fav ? "Remover favorito" : "Favoritar"}
            >
              <svg width="16" height="16" fill={fav ? "#e74c3c" : "none"} stroke={fav ? "#e74c3c" : "var(--gray-400)"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
              </svg>
            </button>
            <button
              onClick={handleList}
              style={{
                width: 32, height: 32, borderRadius: "var(--radius-full)",
                display: "flex", alignItems: "center", justifyContent: "center",
                background: inList ? "var(--green-50)" : "var(--gray-100)",
                transition: "background 0.15s",
              }}
              title={inList ? "Remover da lista" : "Adicionar à lista"}
            >
              <svg width="16" height="16" fill="none" stroke={inList ? "var(--green-600)" : "var(--gray-400)"} strokeWidth="2.5" strokeLinecap="round">
                {inList
                  ? <><path d="M5 12l4 4L19 7"/></>
                  : <><path d="M12 5v14M5 12h14"/></>
                }
              </svg>
            </button>
          </>
        )}
      </div>
    </div>
  );
}
