import { createContext, useContext, useState, useEffect } from "react";
import { useAuth } from "./AuthContext";

const ListContext = createContext(null);

export function ListProvider({ children }) {
  const { isLogged } = useAuth();
  const [list, setList] = useState([]);
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    if (isLogged) {
      const l = localStorage.getItem("jpcs_shoppinglist");
      const f = localStorage.getItem("jpcs_favorites");
      if (l) try { setList(JSON.parse(l)); } catch (_) { /* ignore */ }
      if (f) try { setFavorites(JSON.parse(f)); } catch (_) { /* ignore */ }
    } else {
      setList([]);
      setFavorites([]);
    }
  }, [isLogged]);

  const saveList = (newList) => {
    setList(newList);
    localStorage.setItem("jpcs_shoppinglist", JSON.stringify(newList));
  };

  const saveFavorites = (newFavs) => {
    setFavorites(newFavs);
    localStorage.setItem("jpcs_favorites", JSON.stringify(newFavs));
  };

  const addToList = (product) => {
    if (list.find((i) => i.id === product.id)) return;
    saveList([...list, { ...product, checked: false }]);
  };

  const removeFromList = (productId) => {
    saveList(list.filter((i) => i.id !== productId));
  };

  const toggleChecked = (productId) => {
    saveList(list.map((i) => i.id === productId ? { ...i, checked: !i.checked } : i));
  };

  const toggleFavorite = (product) => {
    if (favorites.find((f) => f.id === product.id)) {
      saveFavorites(favorites.filter((f) => f.id !== product.id));
    } else {
      saveFavorites([...favorites, product]);
    }
  };

  const isFavorite = (productId) => favorites.some((f) => f.id === productId);
  const isInList = (productId) => list.some((i) => i.id === productId);

  return (
    <ListContext.Provider value={{
      list, favorites,
      addToList, removeFromList, toggleChecked,
      toggleFavorite, isFavorite, isInList,
    }}>
      {children}
    </ListContext.Provider>
  );
}

export const useList = () => useContext(ListContext);
