import { useState } from "react";
import { useList } from "../context/ListContext";
import { useAuth } from "../context/AuthContext";

export default function ShoppingList({ setPage }) {
  const { isLogged } = useAuth();
  const { list, favorites, removeFromList, toggleChecked, toggleFavorite } = useList();
  const [tab, setTab] = useState("list");

  if (!isLogged) {
    return (
      <div style={{
        display: "flex", flexDirection: "column", alignItems: "center",
        justifyContent: "center", padding: "80px 32px",
        textAlign: "center",
      }}>
        <p style={{ fontSize: 48, marginBottom: 16 }}>🔒</p>
        <p style={{
          fontFamily: "var(--font-display)", fontWeight: 700,
          fontSize: 20, color: "var(--gray-900)", marginBottom: 8,
        }}>
          Faça login para usar esta função
        </p>
        <p style={{ fontSize: 14, color: "var(--gray-500)", marginBottom: 24 }}>
          Crie uma conta gratuita para montar sua lista de compras e favoritar produtos.
        </p>
        <button
          onClick={() => setPage("login")}
          style={{
            padding: "14px 32px",
            background: "var(--green-500)", color: "var(--white)",
            borderRadius: "var(--radius-md)",
            fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 16,
          }}
        >
          Criar conta / Entrar
        </button>
      </div>
    );
  }

  const items = tab === "list" ? list : favorites;
  const checked = list.filter((i) => i.checked).length;

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: "var(--green-600)", padding: "20px 16px 24px" }}>
        <p style={{
          fontFamily: "var(--font-display)", fontWeight: 800,
          fontSize: 22, color: "var(--white)", marginBottom: 4,
        }}>
          {tab === "list" ? "Minha lista 🛒" : "Favoritos ❤️"}
        </p>
        {tab === "list" && list.length > 0 && (
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.75)" }}>
            {checked} de {list.length} item{list.length !== 1 ? "s" : ""} marcado{checked !== 1 ? "s" : ""}
          </p>
        )}
      </div>

      {/* Tabs */}
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr",
        background: "var(--gray-100)", margin: "16px 16px 0",
        borderRadius: "var(--radius-md)", padding: 4,
      }}>
        {[
          { id: "list", label: `Lista (${list.length})` },
          { id: "favorites", label: `Favoritos (${favorites.length})` },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              padding: "10px",
              borderRadius: "var(--radius-sm)",
              fontWeight: 600, fontSize: 14,
              background: tab === t.id ? "var(--white)" : "transparent",
              color: tab === t.id ? "var(--green-600)" : "var(--gray-500)",
              boxShadow: tab === t.id ? "var(--shadow-sm)" : "none",
              transition: "all 0.2s",
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ padding: "12px 16px", display: "flex", flexDirection: "column", gap: 10 }}>
        {items.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 0", color: "var(--gray-500)" }}>
            <p style={{ fontSize: 36, marginBottom: 10 }}>
              {tab === "list" ? "🛒" : "❤️"}
            </p>
            <p style={{ fontWeight: 600, marginBottom: 6 }}>
              {tab === "list" ? "Sua lista está vazia" : "Nenhum favorito ainda"}
            </p>
            <p style={{ fontSize: 13 }}>
              {tab === "list"
                ? "Adicione produtos ao navegar pelas ofertas."
                : "Toque no coração em qualquer produto para favoritar."}
            </p>
            <button
              onClick={() => setPage("home")}
              style={{
                marginTop: 20, padding: "12px 28px",
                background: "var(--green-500)", color: "var(--white)",
                borderRadius: "var(--radius-md)",
                fontFamily: "var(--font-display)", fontWeight: 700,
              }}
            >
              Ver ofertas
            </button>
          </div>
        ) : (
          items.map((item, idx) => (
            <div
              key={item.id}
              style={{
                display: "flex", alignItems: "center", gap: 14,
                background: "var(--white)",
                border: "1px solid var(--gray-200)",
                borderRadius: "var(--radius-lg)",
                padding: "14px 16px",
                animation: "fadeUp 0.25s ease both",
                animationDelay: `${idx * 0.05}s`,
                opacity: tab === "list" && item.checked ? 0.5 : 1,
              }}
            >
              {tab === "list" && (
                <button
                  onClick={() => toggleChecked(item.id)}
                  style={{
                    width: 24, height: 24, borderRadius: "var(--radius-full)",
                    border: `2px solid ${item.checked ? "var(--green-500)" : "var(--gray-300)"}`,
                    background: item.checked ? "var(--green-500)" : "transparent",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexShrink: 0, transition: "all 0.15s",
                  }}
                >
                  {item.checked && (
                    <svg width="12" height="12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                      <path d="M2 6l3 3 5-5"/>
                    </svg>
                  )}
                </button>
              )}

              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{
                  fontFamily: "var(--font-display)", fontWeight: 700,
                  fontSize: 15, color: "var(--gray-900)",
                  textDecoration: tab === "list" && item.checked ? "line-through" : "none",
                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                }}>
                  {item.name}
                </p>
                <p style={{ fontSize: 12, color: "var(--gray-500)", marginTop: 2 }}>
                  {item.category || "Sem categoria"} · {item.brand || "Sem marca"}
                </p>
              </div>

              <button
                onClick={() => tab === "list" ? removeFromList(item.id) : toggleFavorite(item)}
                style={{
                  width: 32, height: 32, borderRadius: "var(--radius-full)",
                  background: "var(--gray-100)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <svg width="14" height="14" fill="none"
                  stroke={tab === "list" ? "var(--gray-500)" : "var(--red-400)"}
                  strokeWidth="2.5" strokeLinecap="round">
                  {tab === "list"
                    ? <><path d="M4 7h8M7 4v10"/><rect x="2" y="7" width="12" height="10" rx="2"/><path d="M9 4V3a1 1 0 0 0-2 0v1"/></>
                    : <path d="M4 4l8 8M12 4l-8 8"/>
                  }
                </svg>
              </button>
            </div>
          ))
        )}

        {tab === "list" && list.length > 0 && checked > 0 && (
          <button
            onClick={() => {
              const { list: l, removeFromList: rm } = { list, removeFromList };
              l.filter((i) => i.checked).forEach((i) => rm(i.id));
            }}
            style={{
              padding: "12px", marginTop: 8,
              border: "1.5px dashed var(--gray-300)",
              borderRadius: "var(--radius-md)",
              color: "var(--gray-500)", fontSize: 14, fontWeight: 600,
            }}
          >
            Limpar itens marcados ({checked})
          </button>
        )}
      </div>
    </div>
  );
}
