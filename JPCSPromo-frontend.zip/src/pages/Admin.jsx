import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { api } from "../api";

function Section({ title, children }) {
  return (
    <div style={{
      background: "var(--white)", border: "1px solid var(--gray-200)",
      borderRadius: "var(--radius-lg)", overflow: "hidden", marginBottom: 16,
    }}>
      <div style={{
        padding: "14px 20px",
        borderBottom: "1px solid var(--gray-100)",
        background: "var(--gray-50)",
      }}>
        <p style={{
          fontFamily: "var(--font-display)", fontWeight: 700,
          fontSize: 15, color: "var(--gray-800)",
        }}>
          {title}
        </p>
      </div>
      <div style={{ padding: "16px 20px" }}>
        {children}
      </div>
    </div>
  );
}

function AdminInput({ placeholder, value, onChange, type = "text" }) {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      style={{
        flex: 1, padding: "10px 14px",
        border: "1.5px solid var(--gray-200)",
        borderRadius: "var(--radius-md)",
        fontSize: 14, outline: "none",
        color: "var(--gray-900)",
      }}
      onFocus={(e) => e.target.style.borderColor = "var(--green-400)"}
      onBlur={(e) => e.target.style.borderColor = "var(--gray-200)"}
    />
  );
}

function AdminSelect({ value, onChange, options, placeholder }) {
  return (
    <select
      value={value}
      onChange={onChange}
      style={{
        flex: 1, padding: "10px 14px",
        border: "1.5px solid var(--gray-200)",
        borderRadius: "var(--radius-md)",
        fontSize: 14, outline: "none",
        color: "var(--gray-900)",
        background: "var(--white)",
      }}
    >
      <option value="">{placeholder}</option>
      {options.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
    </select>
  );
}

export default function Admin({ setPage }) {
  const { isAdmin, isLogged } = useAuth();
  const [data, setData] = useState({
    products: [], supermarkets: [], categories: [], brands: [],
  });
  const [feedback, setFeedback] = useState({});
  const [forms, setForms] = useState({
    product: { name: "", category_id: "", brand_id: "", image_url: "" },
    supermarket: { name: "", city: "" },
    offer: { product_id: "", supermarket_id: "", price: "" },
    category: { name: "" },
    brand: { name: "" },
  });

  useEffect(() => {
    if (!isAdmin) return;
    Promise.all([
      api.getProducts(), api.getSupermarkets(),
      api.getCategories(), api.getBrands(),
    ]).then(([products, supermarkets, categories, brands]) => {
      setData({ products, supermarkets, categories, brands });
    });
  }, [isAdmin]);

  const setForm = (section, key, value) => {
    setForms((f) => ({ ...f, [section]: { ...f[section], [key]: value } }));
  };

  const showFeedback = (key, msg, ok = true) => {
    setFeedback((f) => ({ ...f, [key]: { msg, ok } }));
    setTimeout(() => setFeedback((f) => ({ ...f, [key]: null })), 3000);
  };

  const submit = async (section, apiFn, refresh) => {
    try {
      await apiFn(forms[section]);
      showFeedback(section, "Cadastrado com sucesso!");
      const refreshed = await refresh();
      setData((d) => ({ ...d, ...refreshed }));
      setForms((f) => ({
        ...f,
        [section]: Object.fromEntries(Object.keys(f[section]).map((k) => [k, ""])),
      }));
    } catch (err) {
      showFeedback(section, err.message || "Erro ao cadastrar.", false);
    }
  };

  if (!isLogged || !isAdmin) {
    return (
      <div style={{
        display: "flex", flexDirection: "column", alignItems: "center",
        justifyContent: "center", padding: "80px 32px", textAlign: "center",
      }}>
        <p style={{ fontSize: 48, marginBottom: 12 }}>🔒</p>
        <p style={{ fontWeight: 700, fontSize: 18, marginBottom: 8 }}>Acesso restrito</p>
        <p style={{ color: "var(--gray-500)", marginBottom: 20 }}>
          Apenas administradores podem acessar esta área.
        </p>
        <button onClick={() => setPage("home")} style={{
          padding: "12px 28px", background: "var(--green-500)", color: "var(--white)",
          borderRadius: "var(--radius-md)", fontWeight: 700,
        }}>
          Voltar
        </button>
      </div>
    );
  }

  const Feedback = ({ k }) => feedback[k] ? (
    <p style={{
      marginTop: 8, fontSize: 13,
      color: feedback[k].ok ? "var(--green-600)" : "var(--red-400)",
      fontWeight: 600,
    }}>
      {feedback[k].ok ? "✓" : "✗"} {feedback[k].msg}
    </p>
  ) : null;

  const AddBtn = ({ onClick }) => (
    <button
      onClick={onClick}
      style={{
        padding: "10px 20px", background: "var(--green-500)", color: "var(--white)",
        borderRadius: "var(--radius-md)", fontWeight: 700, fontSize: 14,
        flexShrink: 0,
      }}
    >
      Adicionar
    </button>
  );

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: "var(--green-700)", padding: "20px 16px 24px" }}>
        <p style={{
          fontFamily: "var(--font-display)", fontWeight: 800,
          fontSize: 22, color: "var(--white)", marginBottom: 4,
        }}>
          Painel admin ⚙️
        </p>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>
          Cadastre supermercados, produtos e ofertas
        </p>
      </div>

      <div style={{ padding: "16px" }}>
        {/* Categoria */}
        <Section title="Nova categoria">
          <div style={{ display: "flex", gap: 10 }}>
            <AdminInput
              placeholder="Ex: Laticínios"
              value={forms.category.name}
              onChange={(e) => setForm("category", "name", e.target.value)}
            />
            <AddBtn onClick={() => submit("category", api.createCategory,
              async () => ({ categories: await api.getCategories() }))} />
          </div>
          <Feedback k="category" />
          {data.categories.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
              {data.categories.map((c) => (
                <span key={c.id} style={{
                  background: "var(--green-50)", color: "var(--green-700)",
                  borderRadius: "var(--radius-full)", padding: "3px 10px", fontSize: 12, fontWeight: 600,
                }}>{c.name}</span>
              ))}
            </div>
          )}
        </Section>

        {/* Marca */}
        <Section title="Nova marca">
          <div style={{ display: "flex", gap: 10 }}>
            <AdminInput
              placeholder="Ex: Nestlé"
              value={forms.brand.name}
              onChange={(e) => setForm("brand", "name", e.target.value)}
            />
            <AddBtn onClick={() => submit("brand", api.createBrand,
              async () => ({ brands: await api.getBrands() }))} />
          </div>
          <Feedback k="brand" />
          {data.brands.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
              {data.brands.map((b) => (
                <span key={b.id} style={{
                  background: "var(--gray-100)", color: "var(--gray-700)",
                  borderRadius: "var(--radius-full)", padding: "3px 10px", fontSize: 12, fontWeight: 600,
                }}>{b.name}</span>
              ))}
            </div>
          )}
        </Section>

        {/* Supermercado */}
        <Section title="Novo supermercado">
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <AdminInput
              placeholder="Nome do supermercado"
              value={forms.supermarket.name}
              onChange={(e) => setForm("supermarket", "name", e.target.value)}
            />
            <div style={{ display: "flex", gap: 10 }}>
              <AdminInput
                placeholder="Cidade"
                value={forms.supermarket.city}
                onChange={(e) => setForm("supermarket", "city", e.target.value)}
              />
              <AddBtn onClick={() => submit("supermarket", api.createSupermarket,
                async () => ({ supermarkets: await api.getSupermarkets() }))} />
            </div>
          </div>
          <Feedback k="supermarket" />
          {data.supermarkets.length > 0 && (
            <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 4 }}>
              {data.supermarkets.map((s) => (
                <p key={s.id} style={{ fontSize: 13, color: "var(--gray-600)" }}>
                  • {s.name} {s.city && `— ${s.city}`}
                </p>
              ))}
            </div>
          )}
        </Section>

        {/* Produto */}
        <Section title="Novo produto">
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <AdminInput
              placeholder="Nome do produto"
              value={forms.product.name}
              onChange={(e) => setForm("product", "name", e.target.value)}
            />
            <AdminInput
              placeholder="URL da imagem (opcional)"
              value={forms.product.image_url}
              onChange={(e) => setForm("product", "image_url", e.target.value)}
            />
            <div style={{ display: "flex", gap: 10 }}>
              <AdminSelect
                value={forms.product.category_id}
                onChange={(e) => setForm("product", "category_id", e.target.value)}
                options={data.categories}
                placeholder="Categoria"
              />
              <AdminSelect
                value={forms.product.brand_id}
                onChange={(e) => setForm("product", "brand_id", e.target.value)}
                options={data.brands}
                placeholder="Marca"
              />
            </div>
            <AddBtn onClick={() => submit("product", api.createProduct,
              async () => ({ products: await api.getProducts() }))} />
          </div>
          <Feedback k="product" />
        </Section>

        {/* Oferta */}
        <Section title="Nova oferta">
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <AdminSelect
              value={forms.offer.product_id}
              onChange={(e) => setForm("offer", "product_id", Number(e.target.value))}
              options={data.products}
              placeholder="Selecionar produto"
            />
            <AdminSelect
              value={forms.offer.supermarket_id}
              onChange={(e) => setForm("offer", "supermarket_id", Number(e.target.value))}
              options={data.supermarkets}
              placeholder="Selecionar supermercado"
            />
            <div style={{ display: "flex", gap: 10 }}>
              <AdminInput
                type="number"
                placeholder="Preço (ex: 4.99)"
                value={forms.offer.price}
                onChange={(e) => setForm("offer", "price", Number(e.target.value))}
              />
              <AddBtn onClick={() => submit("offer", api.createOffer,
                async () => ({}))} />
            </div>
          </div>
          <Feedback k="offer" />
        </Section>
      </div>
    </div>
  );
}
