import { useEffect, useState, useMemo } from "react";
import { api } from "../api";
import ProductCard from "../components/ProductCard";
import PriceSheet from "../components/PriceSheet";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [cheapest, setCheapest] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.getProducts(),
      api.getCheapest(),
    ]).then(([prods, cheap]) => {
      setProducts(prods);
      setCheapest(cheap);
      const cats = [...new Set(prods.map((p) => p.category).filter(Boolean))];
      setCategories(cats);
    }).finally(() => setLoading(false));
  }, []);

  const cheapestMap = useMemo(() => {
    const map = {};
    cheapest.forEach((c) => {
      map[c.id] = { price: c.price, supermarket: c.supermarket };
    });
    return map;
  }, [cheapest]);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
      const matchCat = selectedCategory === "all" || p.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [products, search, selectedCategory]);

  const highlights = cheapest.slice(0, 6);

  return (
    <div style={{ paddingBottom: 80 }}>
      {/* Hero / search */}
      <div style={{
        background: "linear-gradient(160deg, var(--green-600) 0%, var(--green-500) 100%)",
        padding: "20px 16px 24px",
      }}>
        <p style={{
          fontFamily: "var(--font-display)", fontWeight: 800,
          fontSize: 22, color: "var(--white)", marginBottom: 4,
        }}>
          Encontre o menor preço 🏷️
        </p>
        <p style={{ fontSize: 13, color: "rgba(255,255,255,0.75)", marginBottom: 14 }}>
          Compare preços em supermercados da sua região
        </p>
        <div style={{ position: "relative" }}>
          <svg
            width="18" height="18" fill="none" stroke="var(--gray-400)"
            strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
            style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)" }}
          >
            <circle cx="8" cy="8" r="5"/><path d="M21 21l-4.35-4.35"/>
          </svg>
          <input
            type="text"
            placeholder="Buscar produto..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: "100%", padding: "13px 16px 13px 42px",
              borderRadius: "var(--radius-lg)",
              border: "none", outline: "none",
              fontSize: 15, background: "var(--white)",
              color: "var(--gray-900)",
              boxShadow: "var(--shadow-md)",
            }}
          />
        </div>
      </div>

      {/* Destaques */}
      {!loading && highlights.length > 0 && search === "" && (
        <div style={{ padding: "20px 0 0" }}>
          <p style={{
            fontFamily: "var(--font-display)", fontWeight: 700,
            fontSize: 16, color: "var(--gray-900)",
            padding: "0 16px", marginBottom: 12,
          }}>
            🔥 Melhores preços hoje
          </p>
          <div style={{
            display: "flex", gap: 10,
            overflowX: "auto", padding: "0 16px 4px",
          }}>
            {highlights.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  const p = products.find((x) => x.id === item.id);
                  if (p) setSelectedProduct(p);
                }}
                style={{
                  minWidth: 130, background: "var(--white)",
                  border: "1px solid var(--gray-200)",
                  borderRadius: "var(--radius-md)",
                  padding: "12px 14px", textAlign: "left",
                  flexShrink: 0, cursor: "pointer",
                  transition: "border-color 0.15s",
                }}
                onMouseEnter={(e) => e.currentTarget.style.borderColor = "var(--green-400)"}
                onMouseLeave={(e) => e.currentTarget.style.borderColor = "var(--gray-200)"}
              >
                <p style={{
                  fontSize: 12, color: "var(--gray-700)", fontWeight: 600,
                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                  marginBottom: 6,
                }}>
                  {item.product}
                </p>
                <p style={{
                  fontFamily: "var(--font-display)", fontWeight: 800,
                  fontSize: 18, color: "var(--green-600)",
                }}>
                  R$ {Number(item.price).toFixed(2)}
                </p>
                <p style={{ fontSize: 11, color: "var(--gray-400)", marginTop: 3 }}>
                  {item.supermarket}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Categorias */}
      {categories.length > 0 && (
        <div style={{
          display: "flex", gap: 8,
          overflowX: "auto", padding: "16px 16px 0",
        }}>
          {["all", ...categories].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              style={{
                flexShrink: 0, padding: "6px 16px",
                borderRadius: "var(--radius-full)",
                border: `1.5px solid ${selectedCategory === cat ? "var(--green-500)" : "var(--gray-200)"}`,
                background: selectedCategory === cat ? "var(--green-500)" : "var(--white)",
                color: selectedCategory === cat ? "var(--white)" : "var(--gray-600)",
                fontSize: 13, fontWeight: 600,
                transition: "all 0.15s",
                whiteSpace: "nowrap",
              }}
            >
              {cat === "all" ? "Todos" : cat}
            </button>
          ))}
        </div>
      )}

      {/* Lista de produtos */}
      <div style={{ padding: "16px 16px 0", display: "flex", flexDirection: "column", gap: 10 }}>
        {loading ? (
          [1, 2, 3, 4].map((i) => (
            <div key={i} style={{
              height: 80, borderRadius: "var(--radius-lg)",
              background: "var(--gray-100)",
              animation: "pulse 1.2s ease infinite",
              animationDelay: `${i * 0.1}s`,
            }} />
          ))
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 0", color: "var(--gray-500)" }}>
            <p style={{ fontSize: 36, marginBottom: 10 }}>🔍</p>
            <p style={{ fontWeight: 600 }}>Nenhum produto encontrado</p>
            <p style={{ fontSize: 13, marginTop: 4 }}>Tente outro termo de busca</p>
          </div>
        ) : (
          filtered.map((product, idx) => (
            <div key={product.id} style={{ animationDelay: `${idx * 0.04}s` }}>
              <ProductCard
                product={product}
                cheapestPrice={cheapestMap[product.id]?.price}
                supermarket={cheapestMap[product.id]?.supermarket}
                onClick={() => setSelectedProduct(product)}
              />
            </div>
          ))
        )}
      </div>

      <PriceSheet
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
}
